
# Integración aprendizaje incremental (ROS 2 Humble)

Este paquete añade:
- **path_cnn_runtime**: prior de transitabilidad con Small U-Net (ajuste incremental con OccupancyGrid /map). Publica `/path_prior` como `nav_msgs/OccupancyGrid`.
- **continual_nav_learner**: corrige objetivos por intención y publica `/continual_goal`.
- **nav_executor_node**: envía `/navigate_to_pose` a Nav2.

## Build
```bash
source /opt/ros/humble/setup.bash
cd bank_robot_ws_full
colcon build --symlink-install --packages-select bank_robot_bringup
source install/setup.bash
```

## Launch (nodos de aprendizaje)
```bash
ros2 launch bank_robot_bringup bank_branch_learn.launch.py
```
Publica una intención de ejemplo:
```bash
ros2 topic pub /robot_intent std_msgs/String "data: 'cajeros'"
```

> Requisitos recomendados para Humble: **Gazebo Fortress** + **ros_gz** para la integración simulador/ROS, y **gz_ros2_control** para ros2_control en Gazebo Sim. Consulta la tabla de compatibilidad y documentación oficial.  
(Humble + Fortress es el pairing por defecto; `ros_gz` y `ros_gz_sim` proveen los bridges/lanzadores; `gz_ros2_control` conecta ros2_control con Gazebo Sim).  

- Compatibilidad ROS–Gazebo y guía de instalación ros_gz: docs de Gazebo (Jetty/Fortress).  
- Tutorial Humble + Gazebo + ros_gz_bridge.  
- Plugin **gz_ros2_control** para Humble (binarios disponibles) y docs en control.ros.org.

```
Citas en el chat principal.
```
