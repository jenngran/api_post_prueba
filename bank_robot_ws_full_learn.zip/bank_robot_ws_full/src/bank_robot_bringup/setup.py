
from setuptools import setup
from glob import glob

package_name = 'bank_robot_bringup'

setup(
    name=package_name,
    version='0.2.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
        ('share/' + package_name + '/weights', glob('weights/*')),
        ('share/' + package_name + '/rviz', glob('rviz/*.rviz')),
        ('share/' + package_name + '/config', glob('config/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Jenniffer',
    maintainer_email='you@example.com',
    description='Bringup + aprendizaje incremental para entorno bancario',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'robot_service_node = bank_robot_bringup.robot_service_node:main',
            'bank_scene_publisher = bank_robot_bringup.bank_scene_publisher:main',
            'bank_incremental_trainer = bank_robot_bringup.incremental_trainer:main',
            'path_cnn_runtime = bank_robot_bringup.path_cnn_runtime_node:main',
            'continual_nav_learner = bank_robot_bringup.continual_nav_learner:main',
            'nav_executor_node = bank_robot_bringup.nav_executor_node:main',
        ],
    },
)
