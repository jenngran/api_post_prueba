
#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
class BankScenePublisher(Node):
    def __init__(self):
        super().__init__('bank_scene_publisher')

def main():
    rclpy.init(); node=BankScenePublisher(); rclpy.spin(node); rclpy.shutdown()
if __name__=='__main__': main()
