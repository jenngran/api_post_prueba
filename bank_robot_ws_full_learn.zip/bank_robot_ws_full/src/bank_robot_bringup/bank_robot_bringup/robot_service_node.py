
#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
class RobotServiceNode(Node):
    def __init__(self):
        super().__init__('robot_service')

def main():
    rclpy.init(); node=RobotServiceNode(); rclpy.spin(node); rclpy.shutdown()
if __name__=='__main__': main()
