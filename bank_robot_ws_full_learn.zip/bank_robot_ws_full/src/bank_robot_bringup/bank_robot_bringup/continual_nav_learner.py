
#!/usr/bin/env python3
import random
import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry

class ContinualNavLearner(Node):
    def __init__(self):
        super().__init__('continual_nav_learner')
        self.create_subscription(String, 'robot_intent', self.cb_intent, 10)
        self.create_subscription(LaserScan, '/scan', self.cb_scan, 10)
        self.create_subscription(Odometry, '/odom', self.cb_odom, 10)
        self.goal_pub = self.create_publisher(PoseStamped, '/continual_goal', 10)
        self.declare_parameter('max_offset', 0.8)
        self.declare_parameter('batch_size', 32)
        self.declare_parameter('min_buffer', 200)

        self.destinos = {
            'cajeros': np.array([ 2.5, -4.0], dtype=np.float32),
            'servicio_cliente': np.array([-1.0, -2.0], dtype=np.float32),
            'informacion': np.array([ 4.2,  1.5], dtype=np.float32),
        }
        self.replay = []
        self.max_replay = 3000
        self.intent = None
        self.last_scan = None
        self.last_pos = None

    def cb_intent(self, msg):
        self.intent = msg.data
        corrected = self.correct_destination(self.intent)
        self.publish_goal(corrected)

    def cb_scan(self, msg: LaserScan):
        arr = np.array(msg.ranges, dtype=np.float32)
        self.last_scan = np.nan_to_num(arr, nan=msg.range_max)

    def cb_odom(self, msg: Odometry):
        p = msg.pose.pose.position
        self.last_pos = np.array([p.x, p.y], dtype=np.float32)
        if self.intent and self.last_scan is not None and self.last_pos is not None:
            self.store_exp(self.intent, self.last_scan.copy(), self.last_pos.copy())
            self.learn_incremental()

    def store_exp(self, intent, scan, pos):
        if len(self.replay) >= self.max_replay:
            self.replay.pop(0)
        self.replay.append((intent, scan, pos))

    def correct_destination(self, intent):
        base = self.destinos.get(intent)
        if base is None:
            return np.array([0.0, 0.0], dtype=np.float32)
        data = [p for (i, s, p) in self.replay if i == intent]
        if len(data) < 20:
            return base
        offset = np.mean([p - base for p in data], axis=0)
        max_off = float(self.get_parameter('max_offset').get_parameter_value().double_value)
        offset = np.clip(offset, -max_off, max_off)
        return base + offset

    def learn_incremental(self):
        if len(self.replay) < int(self.get_parameter('min_buffer').get_parameter_value().integer_value):
            return
        bs = int(self.get_parameter('batch_size').get_parameter_value().integer_value)
        batch = random.sample(self.replay, min(bs, len(self.replay)))
        for (intent, scan, pos) in batch:
            front = float(np.mean(np.r_[scan[:10], scan[-10:]]))
            if front < 0.7:
                self.destinos[intent] += np.array([0.2, 0.0], dtype=np.float32)

    def publish_goal(self, xy):
        goal = PoseStamped()
        goal.header.frame_id = 'map'
        goal.header.stamp = self.get_clock().now().to_msg()
        goal.pose.position.x = float(xy[0])
        goal.pose.position.y = float(xy[1])
        goal.pose.orientation.w = 1.0
        self.goal_pub.publish(goal)
        self.get_logger().info(f"[GOAL] {self.intent} -> ({xy[0]:.2f}, {xy[1]:.2f})")

def main():
    rclpy.init()
    node = ContinualNavLearner()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
