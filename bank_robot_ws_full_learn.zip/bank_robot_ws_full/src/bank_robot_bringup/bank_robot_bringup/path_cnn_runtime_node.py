
#!/usr/bin/env python3
import os
import numpy as np
import torch
import torch.nn as nn
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy
from rclpy.time import Time
from nav_msgs.msg import OccupancyGrid
from ament_index_python.packages import get_package_share_directory

class SmallUNet(nn.Module):
    def __init__(self, c=16):
        super().__init__()
        self.enc1 = nn.Sequential(nn.Conv2d(1, c, 3, 1, 1), nn.ReLU(), nn.Conv2d(c, c, 3, 1, 1), nn.ReLU())
        self.pool = nn.MaxPool2d(2)
        self.enc2 = nn.Sequential(nn.Conv2d(c, 2*c, 3, 1, 1), nn.ReLU())
        self.up   = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.dec1 = nn.Sequential(nn.Conv2d(3*c, c, 3, 1, 1), nn.ReLU(), nn.Conv2d(c, 1, 1))
        self.act  = nn.Sigmoid()
    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        u  = self.up(e2)
        z  = torch.cat([u, e1], dim=1)
        return self.act(self.dec1(z))

class PathCNNRuntime(Node):
    def __init__(self):
        super().__init__('path_cnn_runtime')
        self.declare_parameter('weights_path', '')
        self.declare_parameter('enable_training', True)
        self.declare_parameter('publish_topic', '/path_prior')
        self.declare_parameter('train_period_sec', 0.5)

        self.enable_training = bool(self.get_parameter('enable_training').get_parameter_value().bool_value)
        self.pub_topic = str(self.get_parameter('publish_topic').get_parameter_value().string_value)
        period = float(self.get_parameter('train_period_sec').get_parameter_value().double_value)

        # resolve weights path
        weights_param = str(self.get_parameter('weights_path').get_parameter_value().string_value)
        if weights_param:
            weights_path = weights_param
        else:
            try:
                share = get_package_share_directory('bank_robot_bringup')
                weights_path = os.path.join(share, 'weights', 'path_prior.pt')
            except Exception:
                weights_path = 'weights/path_prior.pt'

        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.net = SmallUNet().to(self.device)
        if os.path.exists(weights_path):
            self.net.load_state_dict(torch.load(weights_path, map_location=self.device))
            self.get_logger().info(f'[PathCNN] Pesos cargados desde {weights_path}')
        else:
            self.get_logger().warn(f'[PathCNN] No se encontraron pesos en {weights_path}. Iniciando desde cero.')

        self.net.eval()
        self.opt = torch.optim.Adam(self.net.parameters(), lr=1e-4)
        self.bce = nn.BCELoss(reduction='none')

        qos = QoSProfile(depth=1)
        qos.reliability = QoSReliabilityPolicy.BEST_EFFORT
        self.sub_map = self.create_subscription(OccupancyGrid, '/map', self.cb_map, qos)
        self.pub_prior = self.create_publisher(OccupancyGrid, self.pub_topic, 10)

        self.last_x = None   # tensor [1,1,H,W] float32
        self.mask   = None   # tensor [1,1,H,W] float32 (1: válida)
        self.target = None   # tensor [1,1,H,W] float32 (libre=1)
        self.last_info = None
        self.last_header = None

        self.create_timer(period, self.update)

    def cb_map(self, msg: OccupancyGrid):
        w = msg.info.width
        h = msg.info.height
        data = np.array(msg.data, dtype=np.int16).reshape(h, w)
        # target: libre=1 (0), ocupado=0 (>50), unknown=-1 ignorado
        free = (data == 0).astype(np.float32)
        mask = (data >= 0).astype(np.float32)
        x = (data > 50).astype(np.float32)  # 1 si ocupado
        # entrada a la red como "ocupado" (la red aprende transitabilidad=1-free)
        x = torch.from_numpy(x[None, None, ...]).to(self.device)
        self.last_x = x
        self.target = torch.from_numpy(free[None, None, ...]).to(self.device)
        self.mask = torch.from_numpy(mask[None, None, ...]).to(self.device)
        self.last_info = msg.info
        self.last_header = msg.header

    def update(self):
        if self.last_x is None:
            return
        # forward
        pred = self.net(self.last_x).clamp(1e-6, 1-1e-6)
        # entrenamiento opcional en línea
        if self.enable_training:
            loss_map = self.bce(pred, self.target)
            m = self.mask
            denom = torch.clamp(m.sum(), min=1.0)
            loss = (loss_map * m).sum() / denom
            self.opt.zero_grad()
            loss.backward()
            self.opt.step()
            self.net.eval()
            self.get_logger().info(f'[PathCNN] incremental loss={float(loss.item()):.4f}')

        # publicar prior como OccupancyGrid (0..100)
        with torch.no_grad():
            grid = (pred[0,0].detach().cpu().numpy()*100.0).astype(np.int8)
        out = OccupancyGrid()
        out.header.frame_id = self.last_header.frame_id or 'map'
        out.header.stamp = self.get_clock().now().to_msg()
        out.info = self.last_info
        out.data = grid.flatten().tolist()
        self.pub_prior.publish(out)


def main():
    rclpy.init()
    node = PathCNNRuntime()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
