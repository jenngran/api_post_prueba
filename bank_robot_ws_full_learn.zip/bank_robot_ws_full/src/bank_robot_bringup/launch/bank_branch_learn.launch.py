
from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    share = get_package_share_directory('bank_robot_bringup')
    weights = os.path.join(share, 'weights', 'path_prior.pt')

    return LaunchDescription([
        Node(
            package='bank_robot_bringup',
            executable='path_cnn_runtime',
            name='path_cnn_runtime',
            output='screen',
            parameters=[{
                'weights_path': weights,
                'enable_training': True,
                'publish_topic': '/path_prior',
                'train_period_sec': 0.5,
            }]
        ),
        Node(
            package='bank_robot_bringup',
            executable='continual_nav_learner',
            name='continual_nav_learner',
            output='screen',
        ),
        Node(
            package='bank_robot_bringup',
            executable='nav_executor_node',
            name='nav_executor_node',
            output='screen',
        ),
    ])
