
# Bank Robot Workspace (ROS2) — Versión completa

Paquetes:
- **bank_robot_nlp**: NLP incremental de intenciones (scikit‑learn `partial_fit`).
- **bank_robot_routes**: Aprendizaje incremental de rutas + puente Nav2.
- **bank_robot_pathlearn**: Preentrenamiento con Kaggle 2D Path Planning + actualización incremental en runtime.
- **bank_robot_eval**: Herramientas de evaluación y escenario.
- **bank_robot_bringup**: Lanzamiento unificado y `worlds/` con `banco_realista.world`.

Referencias útiles:
- Incremental/online con scikit‑learn (notebook Kaggle): https://www.kaggle.com/code/unofficialmerve/incremental-online-training-with-scikit-learn
- KITTI‑odometry (notebook Kaggle): https://www.kaggle.com/code/ruithemid/kitti-odometry
- 2D Path Planning dataset (Kaggle): https://www.kaggle.com/datasets/dcaffo/2dpathplanningdataset y demo CNN: https://github.com/dcaffo98/path-planning-cnn
- Documentación Nav2: https://docs.nav2.org/

## Build
```bash
cd bank_robot_ws_full
colcon build --symlink-install
source install/setup.bash
```

## Run
Lanza Nav2 (mapa/SLAM según tu flujo) y luego:
```bash
ros2 launch bank_robot_bringup robot_service.launch.py
# Simular usuario:
ros2 topic pub /user_text std_msgs/String "data: 'quiero hacer un deposito'"
```

## Preentrenamiento (opcional)
Ejecuta `bank_robot_pathlearn/path_cnn_pretrain.py` para descargar el dataset 2D de Kaggle y entrenar la CNN; se guardan pesos en `weights/path_prior.pt`. Luego descomenta el nodo `path_cnn_runtime_node` en el launch.

## KPIs sugeridos
- **Accuracy NLP** (% correcto sobre 30 frases).
- **Tiempo medio a objetivo** (desde `/continual_goal` a d≤0.4m).
- **Éxito de navegación** (#goals logrados / enviados).
- **Near‑miss** (veces con min(front)<0.5 m durante la ruta).
- **Recoveries Nav2** (opcional).
