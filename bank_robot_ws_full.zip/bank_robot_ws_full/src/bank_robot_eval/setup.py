
from setuptools import setup
package_name = 'bank_robot_eval'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Jenniffer',
    maintainer_email='you@example.com',
    description='bank_robot_eval package',
    license='MIT',
    entry_points={
        'console_scripts': ['scenario_player = bank_robot_eval.scenario_player:main', 'demo_metrics = bank_robot_eval.demo_metrics:main']
    },
)
