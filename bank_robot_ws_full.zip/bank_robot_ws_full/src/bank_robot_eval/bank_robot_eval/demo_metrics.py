#!/usr/bin/env python3
import rclpy, math, time
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
class DemoMetrics(Node):
    def __init__(self):
        super().__init__('demo_metrics')
        self.create_subscription(PoseStamped,'/continual_goal', self.on_goal,10)
        self.create_subscription(Odometry,'/odom', self.on_odom,10)
        self.create_subscription(LaserScan,'/scan', self.on_scan,10)
        self.goal=None; self.t0=None; self.succ=0; self.goals=0; self.tsum=0.0; self.near=0
        self.create_timer(15.0, self.report)
    def on_goal(self, msg: PoseStamped):
        self.goal=(msg.pose.position.x, msg.pose.position.y); self.t0=time.time(); self.goals+=1
    def on_odom(self, msg: Odometry):
        if not self.goal or self.t0 is None: return
        x=msg.pose.pose.position.x; y=msg.pose.pose.position.y
        d=math.hypot(self.goal[0]-x, self.goal[1]-y)
        if d<0.4:
            dt=time.time()-self.t0; self.succ+=1; self.tsum+=dt
            self.get_logger().info(f"[METRIC] objetivo en {dt:.1f}s"); self.goal=None; self.t0=None
    def on_scan(self, msg: LaserScan):
        front=list(msg.ranges[:10])+list(msg.ranges[-10:])
        front=[r for r in front if not math.isinf(r) and not math.isnan(r)]
        if front and min(front)<0.5: self.near+=1
    def report(self):
        if self.goals==0: return
        avg=self.tsum/max(1,self.succ)
        self.get_logger().info(f"[REPORT] goals={self.goals} success={self.succ} avg_time={avg:.1f}s near_miss={self.near}")

def main():
    rclpy.init(); node=DemoMetrics(); rclpy.spin(node); rclpy.shutdown()

if __name__=='__main__': main()
