#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
PHRASES=["quiero hacer un deposito","quiero sacar un prestamo","quiero mas informacion"]
class ScenarioPlayer(Node):
    def __init__(self):
        super().__init__('scenario_player'); self.pub=self.create_publisher(String,'user_text',10)
        self.i=0; self.create_timer(8.0, self.tick)
    def tick(self):
        msg=String(); msg.data=PHRASES[self.i%len(PHRASES)]; self.pub.publish(msg)
        self.get_logger().info(f"[Scenario] '{msg.data}'"); self.i+=1

def main():
    rclpy.init(); node=ScenarioPlayer(); rclpy.spin(node); rclpy.shutdown()

if __name__=='__main__': main()
