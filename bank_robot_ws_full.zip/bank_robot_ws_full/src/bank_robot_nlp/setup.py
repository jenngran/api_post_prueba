
from setuptools import setup
package_name = 'bank_robot_nlp'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Jenniffer',
    maintainer_email='you@example.com',
    description='bank_robot_nlp package',
    license='MIT',
    entry_points={
        'console_scripts': ['nlp_intention_node = bank_robot_nlp.nlp_intention_node:main']
    },
)
