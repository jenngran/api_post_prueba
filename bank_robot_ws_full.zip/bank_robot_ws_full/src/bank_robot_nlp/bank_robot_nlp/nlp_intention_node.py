#!/usr/bin/env python3
import rclpy, yaml, os, numpy as np
from rclpy.node import Node
from std_msgs.msg import String
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier

class NLPIntentNode(Node):
    def __init__(self):
        super().__init__('nlp_intention_node')
        self.sub = self.create_subscription(String, 'user_text', self.cb_text, 10)
        self.pub_intent = self.create_publisher(String, 'robot_intent', 10)
        self.pub_debug  = self.create_publisher(String, 'nlp_debug', 10)
        cfg_path = os.path.join(os.path.dirname(__file__), 'intents.yaml')
        with open(cfg_path,'r') as f:
            self.cfg = yaml.safe_load(f)['intents']
        self.vectorizer = TfidfVectorizer(ngram_range=(1,2), min_df=1)
        self.clf = SGDClassifier(loss='log_loss', alpha=1e-4)
        self.intent_names = list(self.cfg.keys())
        self._classes = np.arange(len(self.intent_names))
        self.warm = False
        seed_text, seed_y = [], []
        for idx,(name,meta) in enumerate(self.cfg.items()):
            for k in meta.get('keywords',[]):
                seed_text.append(k); seed_y.append(idx)
        X0 = self.vectorizer.fit_transform(seed_text)
        self.clf.partial_fit(X0, np.array(seed_y), classes=self._classes)
        self.warm = True
        self.get_logger().info(f"[NLP] Seed con {len(seed_text)} frases")
    def cb_text(self, msg: String):
        text = msg.data.lower().strip()
        X = self.vectorizer.transform([text]) if self.warm else self.vectorizer.fit_transform([text])
        if not self.warm:
            self.clf.partial_fit(X, np.array([0]), classes=self._classes)
            self.warm = True
        yhat = self.clf.predict(X)[0]
        proba = self.clf.predict_proba(X)[0].max()
        if proba < 0.60:
            yhat = self.intent_names.index('informacion')
            self.clf.partial_fit(X, np.array([yhat]))
        intent_name = self.intent_names[yhat]
        self.pub_intent.publish(String(data=intent_name))
        self.pub_debug.publish(String(data=f"texto='{text}' → intent={intent_name} (p≈{proba:.2f})"))

def main():
    rclpy.init(); node=NLPIntentNode(); rclpy.spin(node); rclpy.shutdown()

if __name__=='__main__':
    main()
