from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(package='bank_robot_nlp', executable='nlp_intention_node', output='screen'),
        Node(package='bank_robot_routes', executable='continual_nav_learner', output='screen'),
        Node(package='bank_robot_routes', executable='nav_executor_node', output='screen'),
        Node(package='bank_robot_eval', executable='scenario_player', output='screen'),
        Node(package='bank_robot_eval', executable='demo_metrics', output='screen'),
        # Node(package='bank_robot_pathlearn', executable='path_cnn_runtime_node', output='screen'),
    ])
