#!/usr/bin/env python3
import os, numpy as np, torch, torch.nn as nn
import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid

class SmallUNet(nn.Module):
    def __init__(self,c=16):
        super().__init__()
        self.enc1=nn.Sequential(nn.Conv2d(1,c,3,1,1),nn.ReLU(),nn.Conv2d(c,c,3,1,1),nn.ReLU())
        self.pool=nn.MaxPool2d(2)
        self.enc2=nn.Sequential(nn.Conv2d(c,2*c,3,1,1),nn.ReLU())
        self.up=nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.dec1=nn.Sequential(nn.Conv2d(3*c,c,3,1,1),nn.ReLU(),nn.Conv2d(c,1,1))
        self.act=nn.Sigmoid()
    def forward(self,x):
        e1=self.enc1(x); e2=self.enc2(self.pool(e1)); u=self.up(e2)
        z=torch.cat([u,e1],dim=1); return self.act(self.dec1(z))

class PathCNNRuntime(Node):
    def __init__(self):
        super().__init__('path_cnn_runtime')
        self.device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.net=SmallUNet().to(self.device)
        if os.path.exists('weights/path_prior.pt'):
            self.net.load_state_dict(torch.load('weights/path_prior.pt', map_location=self.device))
            self.get_logger().info('[PathCNN] Pesos cargados.')
        self.net.eval(); self.opt=torch.optim.Adam(self.net.parameters(), lr=1e-4); self.bce=nn.BCELoss()
        self.create_subscription(OccupancyGrid,'/map', self.cb_map, 10); self.last=None
        self.create_timer(0.5, self.update)
    def cb_map(self, msg: OccupancyGrid):
        w=msg.info.width; h=msg.info.height
        data=np.array(msg.data, dtype=np.int16).reshape(h,w)
        occ=(data>50).astype(np.float32)
        self.last=torch.from_numpy(occ[None,None,...]).to(self.device)
    def update(self):
        if self.last is None: return
        self.net.train(); pred=self.net(self.last); target=(self.last==0.0).float(); loss=self.bce(pred,target)
        self.opt.zero_grad(); loss.backward(); self.opt.step(); self.net.eval()
        self.get_logger().info(f'[PathCNN] incremental loss={float(loss.item()):.4f}')

def main():
    rclpy.init(); node=PathCNNRuntime(); rclpy.spin(node); rclpy.shutdown()

if __name__=='__main__':
    main()
