#!/usr/bin/env python3
import os, glob, numpy as np
import torch, torch.nn as nn, torch.optim as optim
from torch.utils.data import Dataset, DataLoader

try:
    import opendatasets as od
    if not os.path.exists('2dpathplanningdataset'):
        od.download('https://www.kaggle.com/datasets/dcaffo/2dpathplanningdataset')
except Exception as e:
    print('Aviso Kaggle/od:', e)

class GridDataset(Dataset):
    def __init__(self, root='2dpathplanningdataset'):
        self.samples = []
        for npz in glob.glob(os.path.join(root, '**', '*.npz'), recursive=True):
            self.samples.append(npz)
        if not self.samples:
            raise RuntimeError('No .npz encontrados; verifica la estructura del dataset')
    def __len__(self): return len(self.samples)
    def __getitem__(self, idx):
        d = np.load(self.samples[idx])
        x = torch.from_numpy(d['grid'].astype(np.float32))[None,...]
        y = torch.from_numpy(d['path'].astype(np.float32))[None,...]
        return x, y

class SmallUNet(nn.Module):
    def __init__(self,c=16):
        super().__init__()
        self.enc1=nn.Sequential(nn.Conv2d(1,c,3,1,1),nn.ReLU(),nn.Conv2d(c,c,3,1,1),nn.ReLU())
        self.pool=nn.MaxPool2d(2)
        self.enc2=nn.Sequential(nn.Conv2d(c,2*c,3,1,1),nn.ReLU())
        self.up=nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.dec1=nn.Sequential(nn.Conv2d(3*c,c,3,1,1),nn.ReLU(),nn.Conv2d(c,1,1))
        self.act=nn.Sigmoid()
    def forward(self,x):
        e1=self.enc1(x); e2=self.enc2(self.pool(e1)); u=self.up(e2)
        z=torch.cat([u,e1],dim=1); return self.act(self.dec1(z))

if __name__=='__main__':
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ds=GridDataset(); dl=DataLoader(ds,batch_size=8,shuffle=True,num_workers=2)
    net=SmallUNet().to(device); opt=optim.Adam(net.parameters(), lr=1e-3); bce=nn.BCELoss()
    for epoch in range(5):
        net.train(); tot=0.0
        for x,y in dl:
            x,y=x.to(device),y.to(device)
            p=net(x); loss=bce(p,y)
            opt.zero_grad(); loss.backward(); opt.step(); tot+=float(loss.item())
        print(f'epoch {epoch} loss={tot/len(dl):.4f}')
    os.makedirs('weights', exist_ok=True)
    torch.save(net.state_dict(), 'weights/path_prior.pt')
    print('Pesos guardados en weights/path_prior.pt')
