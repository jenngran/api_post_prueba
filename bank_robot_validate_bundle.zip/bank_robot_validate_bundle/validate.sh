
#!/usr/bin/env bash
set -euo pipefail

########################################
# CONFIGURACIÓN BÁSICA (ajusta a tu entorno)
########################################
# Ruta del workspace con los paquetes (bank_robot_ws_full)
WORKSPACE_DIR="$HOME/bank_robot_ws_full"
# Mundo del banco (SDF)
WORLD_PATH="$WORKSPACE_DIR/src/bank_robot_bringup/bank_robot_bringup/worlds/banco_realista.world"
# Modo Nav2: slam | map | custom
NAV2_MODE="slam"
# Si NAV2_MODE=map, especifica YAML
NAV2_MAP="$HOME/maps/bank_map.yaml"
# Si NAV2_MODE=custom, pon aquí tu comando de lanzamiento Nav2 completo
CUSTOM_NAV2_CMD="ros2 launch turtlebot3_navigation2 navigation2.launch.py"

########################################
# PREPARACIÓN
########################################
if [ ! -d "$WORKSPACE_DIR" ]; then
  echo "[ERROR] No existe WORKSPACE_DIR: $WORKSPACE_DIR" >&2
  exit 1
fi
# shellcheck source=/dev/null
source "$WORKSPACE_DIR/install/setup.bash"

RUN_TAG="run-$(date +%Y%m%d-%H%M%S)"
LOG_DIR="logs/$RUN_TAG"
PID_DIR="$LOG_DIR/pids"
mkdir -p "$PID_DIR"

echo "[INFO] Logs en: $LOG_DIR"

########################################
# LANZAR GAZEBO
########################################
(
  echo "[INFO] Lanzando Gazebo con: $WORLD_PATH"
  ros2 launch gazebo_ros gazebo.launch.py world:="$WORLD_PATH"     > "$LOG_DIR/gazebo.log" 2>&1 & echo $! > "$PID_DIR/gazebo.pid"
) &
sleep 3

########################################
# LANZAR NAV2
########################################
case "$NAV2_MODE" in
  slam)
    echo "[INFO] Nav2 en modo SLAM (usa tu launch preferido si difiere)"
    ROS_LOG_FILE="$LOG_DIR/nav2.log"     ros2 launch turtlebot3_cartographer cartographer.launch.py       > "$LOG_DIR/nav2.log" 2>&1 & echo $! > "$PID_DIR/nav2.pid"
    ;;
  map)
    if [ ! -f "$NAV2_MAP" ]; then
      echo "[ERROR] NAV2_MAP no existe: $NAV2_MAP" >&2
      exit 1
    fi
    echo "[INFO] Nav2 en modo mapa estático: $NAV2_MAP"
    ros2 launch turtlebot3_navigation2 navigation2.launch.py map:="$NAV2_MAP"       > "$LOG_DIR/nav2.log" 2>&1 & echo $! > "$PID_DIR/nav2.pid"
    ;;
  custom)
    echo "[INFO] Nav2 modo custom: $CUSTOM_NAV2_CMD"
    bash -lc "$CUSTOM_NAV2_CMD > '$LOG_DIR/nav2.log' 2>&1 & echo $! > '$PID_DIR/nav2.pid'"       || { echo "[ERROR] fallo al lanzar CUSTOM_NAV2_CMD" >&2; exit 1; }
    ;;
  *)
    echo "[ERROR] NAV2_MODE debe ser slam | map | custom" >&2
    exit 1
    ;;
esac
sleep 5

########################################
# LANZAR BRINGUP (NLP + rutas + métricas)
########################################
ros2 launch bank_robot_bringup robot_service.launch.py   > "$LOG_DIR/bringup.log" 2>&1 & echo $! > "$PID_DIR/bringup.pid"

########################################
# RESUMEN
########################################
echo "[OK] Lanzado. PIDs guardados en $PID_DIR"
echo "[INFO] Para detener: bash stop_validate.sh $RUN_TAG"
echo "[INFO] Revisa logs en: $LOG_DIR"

# Espera interactiva opcional
# tail -f "$LOG_DIR/bringup.log"
