
#!/usr/bin/env bash
set -euo pipefail
RUN_TAG="${1:-}"
if [ -z "$RUN_TAG" ]; then
  echo "Uso: bash stop_validate.sh run-YYYYmmdd-HHMMSS" >&2
  exit 1
fi
PID_DIR="logs/$RUN_TAG/pids"
if [ ! -d "$PID_DIR" ]; then
  echo "[ERROR] No existe $PID_DIR" >&2
  exit 1
fi

stop_pid() {
  local file="$1"
  if [ -f "$file" ]; then
    local pid
    pid=$(cat "$file" || true)
    if [ -n "${pid:-}" ] && kill -0 "$pid" 2>/dev/null; then
      echo "[INFO] Deteniendo PID $(basename "$file"): $pid"
      kill "$pid" 2>/dev/null || true
      sleep 2
      kill -9 "$pid" 2>/dev/null || true
    fi
  fi
}

stop_pid "$PID_DIR/bringup.pid"
stop_pid "$PID_DIR/nav2.pid"
stop_pid "$PID_DIR/gazebo.pid"

echo "[OK] Procesos detenidos para $RUN_TAG"
