
# Bank Robot — Paquete de Validación (scripts independientes)

Este paquete añade **scripts de validación** para automatizar una demo end‑to‑end:
- Lanza Gazebo con el **mundo del banco**
- Lanza **Nav2** (trae dos plantillas: SLAM o mapa estático)
- Lanza el **bringup** del robot (NLP + rutas + métricas)
- Guarda **logs** y PIDs para detener todo con un solo comando

> **Requisitos**: Debes tener el workspace `bank_robot_ws_full` compilado (`colcon build`) y
> `source install/setup.bash` disponible. Coloca este paquete **afuera** del workspace (otra carpeta)
> o donde te resulte cómodo; no necesita compilarse.

## Archivos incluidos
- `validate.sh` → script maestro que lanza todo y guarda logs/pids.
- `stop_validate.sh` → detiene de forma ordenada todos los procesos lanzados por `validate.sh`.
- `README_VALIDATE.md` → instrucciones rápidas (este documento).
- `metrics_schema.csv` → cabecera sugerida si deseas acoplar una exportación a CSV de métricas.

## Uso rápido
```bash
# 1) Ajusta variables al inicio de validate.sh si tu ruta difiere
# 2) Ejecuta
bash validate.sh

# 3) Para detener y cerrar todo
bash stop_validate.sh
```

## Variables clave en `validate.sh`
- `WORKSPACE_DIR`: ruta a tu workspace **bank_robot_ws_full**.
- `WORLD_PATH`: mundo SDF del banco (por defecto toma el incluido en bank_robot_bringup).
- `NAV2_MODE`: `slam` o `map`; elige cómo quieres lanzar Nav2.
- `NAV2_MAP` (solo `map`): ruta a tu YAML de mapa si usas navegación sobre mapa estático.

## Salida
- Directorio `logs/run-YYYYmmdd-HHMMSS/` con:
  - `gazebo.log` — salida de Gazebo
  - `nav2.log` — salida de Nav2
  - `bringup.log` — salida del bringup del robot (incluye métricas `[REPORT]`)
  - `pids/` — PIDs de procesos para apagado ordenado

## Notas
- Si usas TurtleBot3 simulado, exporta `TURTLEBOT3_MODEL=burger` o `waffle_pi` en tu shell.
- Si ya tienes un stack Nav2 distinto, deja `NAV2_MODE=custom` y completa `CUSTOM_NAV2_CMD`.
