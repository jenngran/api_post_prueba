
# bank_robot_ws_full (ROS 2 Humble)

Workspace mínimo y funcional con el paquete `bank_robot_bringup`, listo para lanzar `robot_service.launch.py`.

## Estructura

```
bank_robot_ws_full/
└── src/
    └── bank_robot_bringup/
        ├── package.xml
        ├── setup.py
        ├── resource/
        │   └── bank_robot_bringup
        ├── launch/
        │   └── robot_service.launch.py
        └── bank_robot_bringup/
            ├── __init__.py
            └── robot_service_node.py
```

## Cómo compilar y ejecutar

```bash
# 1) Cargar ROS 2 Humble (underlay)
source /opt/ros/humble/setup.bash

# 2) Compilar
cd bank_robot_ws_full
colcon build --symlink-install --packages-select bank_robot_bringup

# 3) Cargar el overlay
source install/setup.bash

# 4) Verificar
ros2 pkg list | grep -i bank_robot_bringup
ros2 pkg prefix bank_robot_bringup
ls $(ros2 pkg prefix bank_robot_bringup)/share/bank_robot_bringup/launch

# 5) Lanzar
ros2 launch bank_robot_bringup robot_service.launch.py
```

Si todo está correcto, verás en consola:

```
[robot_service-1] [INFO] [xxxx.xx] [robot_service]: Robot Service Node iniciado y listo.
[robot_service-1] [INFO] [xxxx.xx] [robot_service]: Heartbeat: bank_robot_bringup activo.
```

## Notas
- Asegúrate de abrir **una nueva terminal** o volver a hacer `source install/setup.bash` cada vez que recompiles.
- Si cambiaste el nombre del paquete, elimina `build/ install/ log/` y recompila.
