
import rclpy
from rclpy.node import Node

class RobotServiceNode(Node):
    def __init__(self):
        super().__init__('robot_service')
        self.get_logger().info('Robot Service Node iniciado y listo.')
        # Aquí podrías declarar timers, services, publishers/subscribers, etc.
        self.timer = self.create_timer(5.0, self._heartbeat)

    def _heartbeat(self):
        self.get_logger().info('Heartbeat: bank_robot_bringup activo.')


def main(args=None):
    rclpy.init(args=args)
    node = RobotServiceNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
