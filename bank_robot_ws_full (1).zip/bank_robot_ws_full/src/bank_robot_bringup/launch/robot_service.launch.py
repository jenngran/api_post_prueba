
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='bank_robot_bringup',
            executable='robot_service_node',
            name='robot_service',
            output='screen',
        ),
    ])
